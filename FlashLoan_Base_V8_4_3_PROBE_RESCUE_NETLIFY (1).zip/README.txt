FLASH LOAN BASE V8.4.3 — NETLIFY PRONTO

1. No Netlify, substitua o index.html anterior por este arquivo.
2. Aguarde a publicação terminar e abra o site em uma aba nova.
3. Toque em “Escanear agora”.
4. Se não houver rota, baixe o diagnóstico: agora ele informa pool inexistente, timeout, revert e saída zero por DEX.

CORREÇÃO PRINCIPAL
- Rotas completas encontradas durante a descoberta são reutilizadas imediatamente como linhas válidas.
- O scanner não perde mais as 6–7 rotas descobertas só porque o tempo restante ficou reservado para refino.
- Pools são validados antes dos Quoters.
- Aerodrome clássico confirma getPool + isPool.
- Limite total: 4min30s.

IMPORTANTE
Sinal verde não é fabricado. Só aparece quando a cotação pending, custos e margem configurada forem realmente positivos.
